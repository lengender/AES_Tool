#include "aesTool.h"
#include "json/json.h"
#include <vector>
#include <fstream>
#include <iostream>
#include <string>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
using namespace std;
int main(int argc, char *argv[])
{

    if(argc < 4)
	{
		cout << "usage: ./long_loan_client ip port  mobile idcard" << endl;
		return -1;
	}

	int sockfd;
	sockfd = socket(AF_INET, SOCK_DGRAM, 0);
	if(sockfd < 0)
	{
		cout << "create sockfd error." << endl;
		return -1;
	}

	struct sockaddr_in serverAddr;
	memset(&serverAddr, 0, sizeof(serverAddr));
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(atoi(argv[2]));

	if((inet_pton(AF_INET, argv[1], &serverAddr.sin_addr.s_addr)) < 0)
	{
		cout << "inet_pton error." << endl;
		return -1;
	}

	string strMobile(argv[3]);
	string strIdcard(argv[4]);

	cout << "phone: " << strMobile << "  idard:" << strIdcard << endl;

	Json::Value input;
    Json::Value tmp;
	tmp["name"] = "phone";
    tmp["key"] = strMobile;
    input.append(tmp);

    tmp["name"] = "idcard";
    tmp["key"] = strIdcard;
    input.append(tmp);

    Json::Value req;
    req["version"] = "1.0";
    req["appid"] = 10001;
    req["subappid"] = 20001;
    req["input"] = input;

   	string strAppid, strTime, strNum;
	srand(time(0));
	uint32_t seconds = time(NULL);
	int num = rand() % 100000;
	stringstream ss;
	ss << 10001;
	ss  >> strAppid;

	ss.clear();
	ss.str("");
	ss << seconds;
	ss >> strTime;

	ss.clear();
	ss.str("");
	ss << num;
	ss >> strNum;

	string text = strAppid + strTime + strNum;
	initKV("zKmnzBvP%FRJs1lD","wwxibsoxZ!Hcurfi");
	cout << strAppid << " time:" << strTime << " num:" << strNum << endl;
	string res = encrypt(text);
    req["sessid"] = res;
	req["timestamp"] = strTime;
	req["randnum"] = strNum;
    string strReq = req.toStyledString();
	size_t rlen = strReq.size();
    
    cout << "request:[" << strReq << "]" << endl;

	char *buf = new char[6 + rlen];
	memset(buf, 0, 6 + rlen);

	*buf = 0x2;
	*(uint32_t*)(buf + 1) = htonl(rlen);
	memcpy(buf + 5, strReq.c_str(), rlen);
	*(buf + 1 + 4 + rlen) = 0x3;

    size_t client_size_t;
	client_size_t = sendto(sockfd, (void*)buf, 6 + rlen, 0, (struct sockaddr*)&serverAddr, sizeof(struct sockaddr));
	delete[] buf;

	if(client_size_t < 0)
	{
		cout << "sendto error." << endl;
		return -1;
	}
	
	char rspBuf[65536] = { 0 };
	size_t size = 0;
	int addr_len = 0;
	size = recvfrom(sockfd, rspBuf, 65536, 0, (struct sockaddr*)&serverAddr, (socklen_t*)&addr_len);

	if(size < 0)
	{
		cout << "recv error." << endl;
		return -1;
	}

	if(rspBuf[0] != 0x2 || rspBuf[size-1] != 0x3)
	{
		cout << "invalid response format." << endl;
		return -1; 
	}

	uint32_t rsplen = ntohl(*(uint32_t*)(rspBuf + 1));

	//解析出json
	Json::Reader reader;
    Json::Value root;
	//reader将Json字符串解析到root，root将包含Json里所有子元素
	if(!reader.parse(rspBuf + 5, rspBuf + 5 + rsplen, root))
	{
		cout << "parse json error." << endl;
		return -1;
	}
	
	string se = root["sessid"].asString();
	string strRsp = root.toStyledString();
	cout << "sessid:[" << se << "]" << endl;
    cout << "response:[" << strRsp << "]" << endl;
	// int seconds = time(NULL);
	// string raw = "10003";
	// stringstream ss;
	// ss << seconds;
	// string se;
	// ss >> se;
	// raw += se + "1000000";
	// cout << seconds << endl;
	// cout << "raw" << raw << endl;
    // initKV("zKmnzBvP%FRJs1lD","wwxibsoxZ!Hcurfi");
	
	// string sessid = encrypt(raw);
	// cout << sessid << ", len:" << sessid.size() << endl;
	// string res = decrypt(sessid);
	// cout << res << endl;
    return 0;
}
